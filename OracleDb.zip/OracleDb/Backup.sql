﻿prompt PL/SQL Developer Export Tables for user C##TN@LOCALHOST
prompt Created by Meloo on 12 Şubat 2022 Cumartesi
set feedback off
set define off

prompt Creating CUSTOMERS...
create table CUSTOMERS
(
  customerid   INTEGER not null,
  customertckn NVARCHAR2(11) not null,
  firstname    NVARCHAR2(50) not null,
  lastname     NVARCHAR2(50) not null,
  birthdate    DATE not null,
  gender       NVARCHAR2(10) not null,
  phone        NVARCHAR2(15),
  address      NVARCHAR2(250)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CUSTOMERS
  add constraint PK_CUSTOMERS_CUSTOMERID primary key (CUSTOMERID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating PRODUCTS...
create table PRODUCTS
(
  productid   INTEGER not null,
  productname NVARCHAR2(100) not null,
  price       NUMBER not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PRODUCTS
  add constraint PK_PRODUCTS_PRODUCTID primary key (PRODUCTID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating POLICIES...
create table POLICIES
(
  policyid   INTEGER not null,
  policyno   NVARCHAR2(50) not null,
  insurerid  INTEGER not null,
  insuredid  INTEGER not null,
  productid  INTEGER not null,
  createdate DATE not null,
  amount     NUMBER not null,
  ispaid     CHAR(1) not null,
  height     INTEGER not null,
  weight     INTEGER not null,
  relation   NVARCHAR2(10) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table POLICIES
  add constraint PK_POLICIES_POLICYID primary key (POLICYID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table POLICIES
  add constraint FK_CUSTOMERS_INSUREDID foreign key (INSUREDID)
  references CUSTOMERS (CUSTOMERID);
alter table POLICIES
  add constraint FK_CUSTOMERS_INSURERID foreign key (INSURERID)
  references CUSTOMERS (CUSTOMERID);
alter table POLICIES
  add constraint FK_PRODUCTS_PRODUCTID foreign key (PRODUCTID)
  references PRODUCTS (PRODUCTID);

prompt Creating PAYMENTS...
create table PAYMENTS
(
  paymentid     INTEGER not null,
  policyid      INTEGER not null,
  isallpaid     CHAR(1) not null,
  paymentpart   INTEGER not null,
  paymentamount NUMBER not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PAYMENTS
  add constraint PK_PAYMENTS_PAYMENTID primary key (PAYMENTID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PAYMENTS
  add constraint FK_POLICIES_POLICYID foreign key (POLICYID)
  references POLICIES (POLICYID);

prompt Creating PAYMENTLINES...
create table PAYMENTLINES
(
  paymentlineid INTEGER not null,
  paymentid     INTEGER,
  partno        INTEGER,
  amount        NUMBER,
  ispaid        CHAR(1)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PAYMENTLINES
  add constraint PK_PAYMENTLINES_PAYMENTLINEID primary key (PAYMENTLINEID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PAYMENTLINES
  add constraint FK_PAYMENTID foreign key (PAYMENTID)
  references PAYMENTS (PAYMENTID) on delete cascade;

prompt Disabling foreign key constraints for POLICIES...
alter table POLICIES disable constraint FK_CUSTOMERS_INSUREDID;
alter table POLICIES disable constraint FK_CUSTOMERS_INSURERID;
alter table POLICIES disable constraint FK_PRODUCTS_PRODUCTID;
prompt Disabling foreign key constraints for PAYMENTS...
alter table PAYMENTS disable constraint FK_POLICIES_POLICYID;
prompt Disabling foreign key constraints for PAYMENTLINES...
alter table PAYMENTLINES disable constraint FK_PAYMENTID;
prompt Truncating PAYMENTLINES...
truncate table PAYMENTLINES;
prompt Truncating PAYMENTS...
truncate table PAYMENTS;
prompt Truncating POLICIES...
truncate table POLICIES;
prompt Truncating PRODUCTS...
truncate table PRODUCTS;
prompt Truncating CUSTOMERS...
truncate table CUSTOMERS;
prompt Loading CUSTOMERS...
insert into CUSTOMERS (customerid, customertckn, firstname, lastname, birthdate, gender, phone, address)
values (1, '12345678901', 'Temuçin', 'Nacar', to_date('29-11-1991', 'dd-mm-yyyy'), 'Erkek', '05378276324', 'Atatürk Mah. 123 Bolu Sok. No:27 Gaziantep');
commit;
prompt 1 records loaded
prompt Loading PRODUCTS...
insert into PRODUCTS (productid, productname, price)
values (1, 'Ayakta Tedavi', 900);
insert into PRODUCTS (productid, productname, price)
values (2, 'Yatarak Tedavi', 1350);
insert into PRODUCTS (productid, productname, price)
values (3, 'Ayakta ve Yatarak Tedavi', 1800);
commit;
prompt 3 records loaded
prompt Loading POLICIES...
insert into POLICIES (policyid, policyno, insurerid, insuredid, productid, createdate, amount, ispaid, height, weight, relation)
values (2, '2e3ce77d-6a82-4ee1-aa9d-607149a99cdd', 1, 1, 2, to_date('12-02-2022 18:13:47', 'dd-mm-yyyy hh24:mi:ss'), 1350, '1', 180, 80, 'Kendisi');
insert into POLICIES (policyid, policyno, insurerid, insuredid, productid, createdate, amount, ispaid, height, weight, relation)
values (1, 'df1ce3f9-e9d2-45a1-9b6b-faf05b85de57', 1, 1, 3, to_date('12-02-2022 18:11:12', 'dd-mm-yyyy hh24:mi:ss'), 1800, '1', 180, 80, 'Kendisi');
insert into POLICIES (policyid, policyno, insurerid, insuredid, productid, createdate, amount, ispaid, height, weight, relation)
values (3, '3ed6c0b0-3814-4cbe-829a-46c81bc31a37', 1, 1, 2, to_date('12-02-2022 18:23:15', 'dd-mm-yyyy hh24:mi:ss'), 1350, '0', 180, 80, 'Kendisi');
commit;
prompt 3 records loaded
prompt Loading PAYMENTS...
insert into PAYMENTS (paymentid, policyid, isallpaid, paymentpart, paymentamount)
values (1, 1, '0', 3, 1800);
insert into PAYMENTS (paymentid, policyid, isallpaid, paymentpart, paymentamount)
values (2, 2, '0', 6, 1350);
insert into PAYMENTS (paymentid, policyid, isallpaid, paymentpart, paymentamount)
values (3, 3, '0', 3, 1350);
commit;
prompt 3 records loaded
prompt Loading PAYMENTLINES...
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (1, 1, 2, 600, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (2, 1, 1, 600, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (5, 2, 6, 225, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (9, 2, 1, 225, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (11, 3, 3, 450, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (6, 2, 4, 225, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (7, 2, 2, 225, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (3, 1, 3, 600, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (4, 2, 5, 225, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (8, 2, 3, 225, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (10, 3, 1, 450, '0');
insert into PAYMENTLINES (paymentlineid, paymentid, partno, amount, ispaid)
values (12, 3, 2, 450, '0');
commit;
prompt 12 records loaded
prompt Enabling foreign key constraints for POLICIES...
alter table POLICIES enable constraint FK_CUSTOMERS_INSUREDID;
alter table POLICIES enable constraint FK_CUSTOMERS_INSURERID;
alter table POLICIES enable constraint FK_PRODUCTS_PRODUCTID;
prompt Enabling foreign key constraints for PAYMENTS...
alter table PAYMENTS enable constraint FK_POLICIES_POLICYID;
prompt Enabling foreign key constraints for PAYMENTLINES...
alter table PAYMENTLINES enable constraint FK_PAYMENTID;

set feedback on
set define on
prompt Done
