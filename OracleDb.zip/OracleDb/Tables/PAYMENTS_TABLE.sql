-- Create table
create table PAYMENTS
(
  paymentid     INTEGER not null,
  policyid      INTEGER not null,
  isallpaid     CHAR(1) not null,
  paymentpart   INTEGER not null,
  paymentamount NUMBER not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table PAYMENTS
  add constraint PK_PAYMENTS_PAYMENTID primary key (PAYMENTID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PAYMENTS
  add constraint FK_POLICIES_POLICYID foreign key (POLICYID)
  references POLICIES (POLICYID);
