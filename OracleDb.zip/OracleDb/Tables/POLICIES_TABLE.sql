-- Create table
create table POLICIES
(
  policyid   INTEGER not null,
  policyno   NVARCHAR2(50) not null,
  insurerid  INTEGER not null,
  insuredid  INTEGER not null,
  productid  INTEGER not null,
  createdate DATE not null,
  amount     NUMBER not null,
  ispaid     CHAR(1) not null,
  height     INTEGER not null,
  weight     INTEGER not null,
  relation   NVARCHAR2(10) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table POLICIES
  add constraint PK_POLICIES_POLICYID primary key (POLICYID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table POLICIES
  add constraint FK_CUSTOMERS_INSUREDID foreign key (INSUREDID)
  references CUSTOMERS (CUSTOMERID);
alter table POLICIES
  add constraint FK_CUSTOMERS_INSURERID foreign key (INSURERID)
  references CUSTOMERS (CUSTOMERID);
alter table POLICIES
  add constraint FK_PRODUCTS_PRODUCTID foreign key (PRODUCTID)
  references PRODUCTS (PRODUCTID);
