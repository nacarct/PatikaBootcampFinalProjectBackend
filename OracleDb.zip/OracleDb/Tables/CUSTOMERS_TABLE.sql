-- Create table
create table CUSTOMERS
(
  customerid   INTEGER not null,
  customertckn NVARCHAR2(11) not null,
  firstname    NVARCHAR2(50) not null,
  lastname     NVARCHAR2(50) not null,
  birthdate    DATE not null,
  gender       NVARCHAR2(10) not null,
  phone        NVARCHAR2(15),
  address      NVARCHAR2(250)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table CUSTOMERS
  add constraint PK_CUSTOMERS_CUSTOMERID primary key (CUSTOMERID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
