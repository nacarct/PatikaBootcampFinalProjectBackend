-- Create sequence 
create sequence SEQ_CUSTOMERID
minvalue 1
maxvalue 999999
start with 21
increment by 1
cache 20;
